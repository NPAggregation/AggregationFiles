clear,clc
N = 27; %Number of particles

Vn = 512.0;     % Atom size, in Angstroms cubed / atom
N = 27;     % Number of atoms
Vol = N*Vn;     % total volume (Angstroms^3)
side = Vol^(1.0/3.0);   % length of side of simulation volume (Angstrom)
dt = 1; %Time Step (fs)
r = zeros(N,3); % position
rcut = 10; %Cut-off between 8 and 14 angstroms
eps = 136; % Depth of the potential well (K or eV) to be decided
sigma = 3.884; % Collision Diameter (Angstroms)
ni = ceil(N^(1.0/3.0));
ULJ = 4*eps*((sigma/rcut)^12-(sigma/rcut)^6);
MW = 16.0;      % molecular weight (grams/mole)
Nav = 6.022e+23; % Avogadro's Number

mass = MW/Nav/1000*1.0e+28;


v = zeros(N,3); % velocity
        a = zeros(N,3); % acceleration
        f = zeros(N,3); % force        
        ncount = 0;
        dx = side/ni;
        for ix = 1:1:ni
            for iy = 1:1:ni
                for iz = 1:1:ni
                    if (ncount <= N)
                        ncount = ncount + 1;
                        r(ncount,1) = dx*ix;
                        r(ncount,2) = dx*iy;
                        r(ncount,3) = dx*iz;
                    end
                end
            end
        end
        
for step = 0:25
        %% Update
        rmass = 1.0 / mass;
        a(1:N,1:3) = f(1:N,1:3)*rmass;
        v(1:N,1:3) = v(1:N,1:3)+0.5*dt*(f(1:N,1:3)*rmass+a(1:N,1:3));
        r(1:N,1:3) = r(1:N,1:3)+v(1:N,1:3)*dt+0.5*a(1:N,1:3)*dt*dt;
        
        figure
        plot3(r(:,1),r(:,2),r(:,3),'or')
ylabel('y'), xlabel('x'),zlabel('z');
ylim([0,ceil(side)]),xlim([0,ceil(side)]),zlim([0,ceil(side)]);
set(gca,'Color',[1 1 1])
grid on
title('Display of r')
        %% Compute
        f = zeros ( N, 3 );
        pot = 0.0;
        for i = 1 : N
            for j = i : N
                if i ~= j
                    for k = 1 : 3
                        rij(k) = r(i,k) - r(j,k);
                    end
                    d = 0.0;
                    for k = 1  : 3
                        d = d + rij(k)^2;
                    end
                    d = sqrt(d);
                    %
                    %  Truncate the distance.
                    %
                    d2 = min ( d, pi / 2.0 );
                    %
                    %  Attribute half of the total potential energy to particle J.
                    %
                    pot = pot + 0.5 * sin ( d2 ) * sin ( d2 );
                    %
                    %  Add particle J's contribution to the force on particle I.
                    %
                    for k = 1 : 3
                        f(i,k) = f(i,k) - rij(k) * sin ( 2.0 * d2 ) / d - ULJ;
                    end               
                end              
            end           
        end
        %
        %  Compute the total kinetic energy.
        %
        kin = 0.5 * mass * sum ( sum ( v(1:N,1:3).^2 ) );

end